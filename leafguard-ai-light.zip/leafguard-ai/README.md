# 🌿 LEAFGUARD AI — Intelligent Plant Leaf Disease Classification System
> **Academic AI / Machine Learning Capstone Project**  
> *Demonstrating the Complete ML Lifecycle: Data Ingestion, Leakage-Free Preprocessing, Baseline CNN vs MobileNetV2 Transfer Learning, Empirical Evaluation, and Responsive Web Deployment.*

---

## 🌟 Executive Summary
**LeafGuard AI** is a fully functional, academically defensible image-classification system designed to detect foliar blights and verify vegetative health across **Potato (*Solanum tuberosum*)** and **Tomato (*Solanum lycopersicum*)** crops. 

Trained and evaluated on the benchmark **PlantVillage dataset**, LeafGuard AI features:
* **MobileNetV2 Transfer Learning Model** (**89.58% Test Accuracy**, **89.76% Macro F1**).
* **Baseline 3-Block CNN Model** (trained from scratch for empirical comparative analysis: 39.58% Test Accuracy).
* **Zero Data Leakage:** Stratified 70% Train, 15% Val, 15% Test split with deduplication and training-only data augmentation.
* **Modern Botanical-Science Web Interface:** Drag-and-drop upload, one-click preset test leaves, animated probability gauges, and agronomic pathology insights.
* **Responsible AI Uncertainty Guardrail:** Automated warnings for low-confidence predictions (< 65%).
* **SQLite History Audit Trail:** Local database logging predictions without retaining user images.

---

## 📁 Project Architecture & Folder Structure

```text
leafguard-ai/
│
├── app.py                     # Flask web server & REST API
├── config.py                  # Central hyperparameters, paths, and botanical metadata
├── database.py                # SQLite prediction audit logging & deletion
├── requirements.txt           # Verified Python package dependencies
├── conftest.py                # Pytest path discovery configuration
├── README.md                  # Complete execution & presentation guide
│
├── ml/
│   ├── dataset_utils.py       # PlantVillage downloader, hash deduplicator & stratified splitter
│   ├── preprocess.py          # Anti-aliased resizing, normalization & training augmentation
│   ├── train_cnn.py           # Custom 3-block CNN baseline training script
│   ├── train_transfer_learning.py # MobileNetV2 ImageNet transfer learning script
│   ├── evaluate.py            # Test set evaluation, metrics calculation & chart generation
│   └── predict.py             # Single-image inference service & uncertainty filter
│
├── models/
│   ├── class_names.json       # Saved class-to-index mapping matching model output order
│   ├── baseline_cnn.keras     # Saved trained Baseline CNN model weights
│   └── mobilenetv2_leafguard.keras # Saved trained MobileNetV2 model weights
│
├── artifacts/
│   ├── evaluation_metrics.json       # Exact computed metrics, per-class stats & confusion pairs
│   ├── confusion_matrix.png          # High-resolution test split confusion matrix heatmap
│   ├── model_comparison.png         # Bar chart comparing CNN vs MobileNetV2
│   ├── training_curves_mobilenet.png # MobileNetV2 loss and accuracy trajectories
│   ├── training_curves_cnn.png       # Baseline CNN training curves
│   └── class_distribution.png        # Stratified Train/Val/Test distribution chart
│
├── templates/
│   ├── index.html             # Page 1: Landing page with lifecycle pipeline & class catalog
│   ├── analyze.html           # Page 2 & 3: Foliar Classification Workspace & Live Results
│   ├── dashboard.html         # Page 4: Model Performance Dashboard
│   └── limitations.html       # Page 5: Dataset Provenance & Responsible AI Report
│
├── static/
│   ├── css/
│   │   └── style.css          # Botanical-science design system (deep forest & sage green)
│   ├── js/
│   │   ├── main.js            # Sticky navigation & smooth scrolling
│   │   ├── upload.js          # Drag-and-drop, client validation & inference controller
│   │   └── dashboard.js       # Live metrics & error sample gallery renderer
│   └── images/
│       └── sample_leaves/     # Preset leaves for one-click instant testing in UI
│
├── tests/
│   ├── test_preprocessing.py  # Unit tests for image validation, corruption & tensors
│   └── test_api.py            # Integration tests for Flask routes, inference & history
│
├── notebooks/
│   └── plant_disease_training.ipynb  # Step-by-step Jupyter notebook for live demo
│
└── docs/
    ├── dataset_documentation.md  # Data provenance, licenses & sampling methodology
    ├── model_card.md             # Standard Model Card specification
    ├── limitations_report.md     # In-depth analysis of laboratory backdrop biases
    └── viva_preparation_guide.md # Viva Q&A, mathematical formulas & defense tips
```

---

## ⚡ Quick Start (Windows Execution Guide)

### 1. Prerequisites
* Python 3.10 or 3.11 installed with pip.
* PowerShell or Command Prompt.

### 2. Create and Activate Virtual Environment (Recommended)
```powershell
# Open terminal inside leafguard-ai directory
cd leafguard-ai

# Create virtual environment
python -m venv venv

# Activate environment
.\venv\Scripts\Activate.ps1
```

### 3. Install Dependencies
```powershell
pip install -r requirements.txt
```

### 4. Run Automated Test Suite
Verify that all 15 unit and integration tests pass:
```powershell
pytest -v
```

### 5. Launch the Web Server
The models and evaluation artifacts are already fully trained and bundled inside `models/` and `artifacts/`!
```powershell
python app.py
```
Open your browser and navigate to:
👉 **`http://127.0.0.1:5000`**

---

## 🧪 Reproducing the Machine Learning Pipeline

If you wish to re-download the dataset, re-train models, or regenerate charts from scratch:

```powershell
# Step 1: Download authentic PlantVillage samples and generate 70/15/15 splits
python ml/dataset_utils.py

# Step 2: Train the custom Baseline CNN
python ml/train_cnn.py

# Step 3: Train the MobileNetV2 Transfer Learning Model
python ml/train_transfer_learning.py

# Step 4: Evaluate both models on test data & generate charts
python ml/evaluate.py
```

---

## 📊 Measured Benchmark Results (Held-Out Test Set)

| Metric | Baseline CNN (Scratch) | MobileNetV2 (Transfer Learning) |
|---|---|---|
| **Test Accuracy** | 39.58% | **89.58%** |
| **Macro Precision** | 47.60% | **90.77%** |
| **Macro Recall** | 39.58% | **89.58%** |
| **Macro F1-Score** | 37.48% | **89.76%** |
| **Weighted F1-Score** | 37.48% | **89.76%** |
| **Training Duration** | 52.2 s | **45.2 s** |

---

## 🛡️ Responsible AI & Ethical Boundaries
* **Academic Prototype:** LeafGuard AI is an educational prototype. Results do not constitute professional agricultural diagnosis.
* **Uncertainty Guardrail:** Inputs with maximum probability below **65%** automatically trigger an uncertainty warning.
* **No Autonomous Spraying:** The system provides cultural management advice only and strictly disclaims automated pesticide application.
* **Dataset Attribution:** Data sourced from the open-access PlantVillage dataset (CC0 1.0 Universal) curated by Hughes & Salathé.
