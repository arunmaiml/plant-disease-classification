"""
LEAFGUARD AI - SQLite Prediction History Database
Persists anonymized classification results without retaining user image files.
Provides clean query and deletion endpoints for privacy.
"""
import sqlite3
import datetime
import os
import config


def get_db_connection():
    conn = sqlite3.connect(config.DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    """Initializes the SQLite prediction history table."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS prediction_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            predicted_class TEXT NOT NULL,
            predicted_display TEXT NOT NULL,
            crop TEXT NOT NULL,
            status TEXT NOT NULL,
            probability REAL NOT NULL,
            model_version TEXT NOT NULL,
            is_uncertain INTEGER NOT NULL
        )
    """)
    conn.commit()
    conn.close()


def record_prediction(predicted_class, predicted_display, crop, status, probability, model_version, is_uncertain):
    """Inserts a new prediction record."""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        now_iso = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        cursor.execute("""
            INSERT INTO prediction_history (
                timestamp, predicted_class, predicted_display, crop, status,
                probability, model_version, is_uncertain
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            now_iso,
            predicted_class,
            predicted_display,
            crop,
            status,
            float(probability),
            model_version,
            1 if is_uncertain else 0
        ))
        conn.commit()
        last_id = cursor.lastrowid
        conn.close()
        return last_id
    except Exception as e:
        print(f"[Database] Error recording prediction: {e}")
        return None


def fetch_history(limit=50):
    """Retrieves recent prediction history ordered by newest first."""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT id, timestamp, predicted_class, predicted_display, crop,
                   status, probability, model_version, is_uncertain
            FROM prediction_history
            ORDER BY id DESC
            LIMIT ?
        """, (limit,))
        rows = cursor.fetchall()
        conn.close()
        history = []
        for r in rows:
            history.append({
                "id": r["id"],
                "timestamp": r["timestamp"],
                "predicted_class": r["predicted_class"],
                "predicted_display": r["predicted_display"],
                "crop": r["crop"],
                "status": r["status"],
                "probability": round(r["probability"] * 100, 1),
                "model_version": r["model_version"],
                "is_uncertain": bool(r["is_uncertain"])
            })
        return history
    except Exception as e:
        print(f"[Database] Error fetching history: {e}")
        return []


def clear_history():
    """Deletes all stored history."""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM prediction_history")
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        print(f"[Database] Error clearing history: {e}")
        return False
