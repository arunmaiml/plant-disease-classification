# LEAFGUARD AI — Capstone Viva & Presentation Guide
### Designed for Second-Year AI / ML Students

---

## 1. Project Pitch (30-Second Elevator Summary)
> *"LeafGuard AI is an educational computer vision capstone that classifies foliar plant diseases across potato and tomato crops. We developed the complete machine learning lifecycle from data cleaning and leakage-free stratified splitting to training a baseline CNN from scratch and fine-tuning an ImageNet-pretrained MobileNetV2. MobileNetV2 achieved 89.58% test accuracy compared to 39.58% for the CNN baseline. We deployed this through a responsive Flask web interface featuring an automated uncertainty guardrail and an SQLite audit trail."*

---

## 2. Frequently Asked Viva Questions & Answers

### Q1: Why did MobileNetV2 significantly outperform the Baseline CNN?
**Answer:**
* MobileNetV2 leverages **Transfer Learning** from ImageNet (1.4 million images, 1,000 classes). Its early and intermediate convolutional filters already know general visual primitives (edges, gradients, textures, organic curves).
* Training a CNN from scratch on a small agricultural dataset suffers from sample scarcity and over-parameterization, leading to underfitting or overfitting.
* Freezing the MobileNetV2 backbone and training only the dense classification head allowed rapid, high-accuracy convergence in just 45 seconds on CPU.

### Q2: What is Depthwise Separable Convolution in MobileNetV2?
**Answer:**
Standard convolution applies a $D_K \times D_K \times M$ filter across all channels simultaneously. MobileNetV2 splits this into:
1. **Depthwise Convolution:** Applies a single $3 \times 3$ filter per input channel independently.
2. **Pointwise Convolution:** Applies a $1 \times 1$ convolution to combine channel features.
* **Computational Cost Reduction:** Reduces computations by roughly $\frac{1}{N} + \frac{1}{D_K^2} \approx \frac{1}{9}$ (an 8- to 9-fold computation reduction compared to standard Conv2D), making it ideal for edge and mobile agricultural devices.

### Q3: How did you prevent Data Leakage?
**Answer:**
1. **Deduplication:** We computed MD5 hashes across raw images to eliminate identical samples before splitting.
2. **Stratified Splitting First:** We partitioned into 70% Train, 15% Validation, and 15% Test *before* performing any data augmentation.
3. **Training-Only Augmentation:** Random rotations, shifts, and zooms were applied strictly to the training generator. Validation and test sets received zero synthetic perturbation.

### Q4: Why is Macro F1-score more important than Overall Accuracy?
**Answer:**
Accuracy can be misleading when class frequencies are unbalanced.
* **Macro F1-Score:** Calculates the harmonic mean of Precision and Recall for *each individual class*, then computes the unweighted average:
  $$\text{Macro F1} = \frac{1}{K} \sum_{k=1}^K \text{F1}_k$$
* It gives equal importance to all conditions, ensuring rare or severe diseases (like Late Blight) are not masked by frequent classes.

### Q5: What is the purpose of the Uncertainty Threshold (0.65)?
**Answer:**
Softmax forces class probabilities to sum to 1.0 even on totally unfamiliar images. If the maximum predicted probability is below 0.65, LeafGuard AI flags the prediction as uncertain, warning the grower that lighting or an unsupported plant species might be responsible, rather than presenting a false sense of certainty.

---

## 3. Key Mathematical Formulas
* **Precision:** $\frac{TP}{TP + FP}$ (Quality of positive predictions)
* **Recall / Sensitivity:** $\frac{TP}{TP + FN}$ (Ability to detect diseased leaves)
* **F1-Score:** $2 \times \frac{\text{Precision} \times \text{Recall}}{\text{Precision} + \text{Recall}}$
* **Categorical Crossentropy Loss:** $L = -\sum_{i=1}^C y_i \log(\hat{y}_i)$
