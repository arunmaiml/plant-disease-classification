# LEAFGUARD AI — Model Card

## 1. Model Details
* **Model Name:** MobileNetV2 LeafGuard Folio-Classifier
* **Model Version:** v1.0.0 (Keras 3 format)
* **Model Date:** October 2026
* **Model Type:** Deep Convolutional Neural Network with Inverted Residuals & Linear Bottlenecks
* **Backbone:** MobileNetV2 (Sandler et al., 2018), pretrained on ImageNet
* **Fine-Tuning:** Frozen backbone with custom classification head (GlobalAveragePooling2D -> Dense 128 -> BatchNorm -> Dropout 0.3 -> Softmax 6 classes)
* **License:** Apache 2.0 (Model architecture) / Academic Capstone Prototype

---

## 2. Intended Use
* **Primary Intended Use:** Educational and academic exploration of deep learning classification of foliar diseases on potato and tomato plants.
* **Intended Users:** Agricultural researchers, computer vision students, precision agriculture educators.
* **Out-of-Scope Uses:** Autonomous chemical application, clinical phytosanitary certification, or replacement of accredited agronomists.

---

## 3. Training Configuration & Hyperparameters
* **Input Resolution:** (224, 224, 3)
* **Normalization:** ImageNet scaling mapping RGB [0, 255] to [-1.0, 1.0]
* **Optimizer:** Adam (Initial Learning Rate = 0.001)
* **Loss Function:** Categorical Crossentropy
* **Batch Size:** 16
* **Epochs Trained:** 10 epochs with Early Stopping (patience=4) and ModelCheckpoint restoring best validation accuracy weights.

---

## 4. Empirical Evaluation on Held-Out Test Set
| Model Architecture | Test Accuracy | Macro Precision | Macro Recall | Macro F1 | Weighted F1 | Training Time |
|---|---|---|---|---|---|---|
| **MobileNetV2 (Transfer Learning)** | **89.58%** | **90.77%** | **89.58%** | **89.76%** | **89.76%** | **45.2 s** |
| **Baseline CNN (Scratch)** | 39.58% | 47.60% | 39.58% | 37.48% | 37.48% | 52.2 s |

---

## 5. Ethical Guidelines & Caveats
1. **Uncertainty Calibration:** Predictions with maximum softmax probability < 0.65 are explicitly flagged with an educational uncertainty warning.
2. **Pathological Overlap:** Potato Early Blight and Tomato Early Blight are caused by the same pathogen (*Alternaria solani*) and exhibit similar concentric ring lesions. Occluded leaflets may cause minor cross-species confusion.
