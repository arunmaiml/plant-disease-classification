# LEAFGUARD AI — Limitations and Responsible-Use Report

## Compulsory Prototype Notice
> **"This system is an educational plant-leaf image-classification prototype. It identifies the most likely category among the classes represented in its training dataset. Predictions may be incorrect, particularly for unsupported species, unfamiliar diseases, poor-quality images, or images that differ from the training data. Results are not a professional agricultural diagnosis. Consult a qualified agricultural expert before making important crop-management decisions."**

---

## 1. Laboratory vs Real-World Distribution Shift
* **Laboratory Dataset Environment:** The PlantVillage images were captured under controlled studio lighting on monochromatic paper cards.
* **In-Field Realities:**
  1. **Lighting Dynamics:** Direct sunlight produces high specular reflection and sharp leaf shadows. Overcast conditions reduce contrast.
  2. **Background Noise:** Soil particles, irrigation drip lines, weeds, and decaying organic mulch confuse edge-detection filters.
  3. **Occlusion & Blurring:** Wind flutter causes motion blur; overlapping leaves create non-standard boundary silhouettes.

---

## 2. Confidence vs Correctness
* Neural network softmax outputs calculate a normalized exponential probability distribution $\frac{e^{z_i}}{\sum e^{z_j}}$.
* **Closed-World Assumption:** The model assigns 100% of its probability mass across the 6 supported classes. Submitting a leaf from an unsupported crop (e.g., Apple Scab or Corn Rust) or an unrelated non-plant object will still force a prediction among the 6 classes.
* **Safety Mechanism:** LeafGuard AI integrates an **Uncertainty Guardrail (Threshold = 0.65)** that warns users when probability is distributed or ambiguous.

---

## 3. Absence of Disease vs Clinical Health
* A classification of **Healthy Foliage** indicates no macroscopic foliar blight lesions are identifiable on that specific photographed leaf surface.
* It does **not** certify that the plant is free of:
  * Early asymptomatic systemic infections (incubation period).
  * Root-knot nematodes (*Meloidogyne spp.*).
  * Vascular bacterial wilts (*Ralstonia solanacearum*).
  * Nutritional deficiencies (nitrogen, magnesium chlorosis).

---

## 4. Pesticide and Fungicide Recommendation Prohibition
* LeafGuard AI provides purely cultural management guidelines (crop rotation, wide plant spacing, drip irrigation instead of overhead sprinklers).
* It strictly prohibits automated chemical dosage calculation or autonomous spray actuation to prevent pesticide overuse and environmental contamination.
