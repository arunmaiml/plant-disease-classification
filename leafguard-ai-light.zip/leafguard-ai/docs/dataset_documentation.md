# LEAFGUARD AI — Dataset Documentation

## 1. Dataset Provenance & Metadata
* **Dataset Name:** PlantVillage Image Dataset
* **Curators:** David P. Hughes & Marcel Salathé (Penn State University & EPFL)
* **Open Repository:** [https://github.com/spMohanty/PlantVillage-Dataset](https://github.com/spMohanty/PlantVillage-Dataset)
* **Citation:** Mohanty, S. P., Hughes, D. P., & Salathé, M. (2016). *Using Deep Learning for Image-Based Plant Disease Detection.* Frontiers in Plant Science, 7, 1419.
* **License:** Creative Commons Zero (CC0 1.0 Universal) — Public Domain Dedication.
* **Permitted Usage:** Academic research, non-commercial education, public benchmarking, derivative models.

---

## 2. Selected Target Classes & Biological Taxonomy
LeafGuard AI focuses on the economically essential Solanaceae nightshade family (Potato and Tomato), spanning two destructive foliar blights and healthy vegetative foliage:

| Class Name | Crop Common Name | Botanical Binomial | Pathogen / Condition | Type |
|---|---|---|---|---|
| `Potato___Early_blight` | Potato | *Solanum tuberosum* | *Alternaria solani* | Fungal pathogen |
| `Potato___Late_blight` | Potato | *Solanum tuberosum* | *Phytophthora infestans* | Oomycete (water mold) |
| `Potato___healthy` | Potato | *Solanum tuberosum* | None detected | Healthy foliage |
| `Tomato___Early_blight` | Tomato | *Solanum lycopersicum* | *Alternaria solani* | Fungal pathogen |
| `Tomato___Late_blight` | Tomato | *Solanum lycopersicum* | *Phytophthora infestans* | Oomycete (water mold) |
| `Tomato___healthy` | Tomato | *Solanum lycopersicum* | None detected | Healthy foliage |

---

## 3. Dataset Characteristics & Partitioning
* **Original Image Format:** RGB JPEG color photographs.
* **Original Resolution:** 256 x 256 pixels.
* **Resampled Model Input:** 224 x 224 pixels (Lanczos anti-aliasing resampling).
* **Sample Count:** 45 images per class (270 total samples across 6 classes).
* **Splitting Strategy:** Stratified random split with fixed seed (`seed=42`):
  * **Training Split (70%):** 186 images (31 per class)
  * **Validation Split (15%):** 36 images (6 per class)
  * **Testing Split (15%):** 48 images (8 per class)

---

## 4. Data Leakage Prevention Controls
To preserve scientific validity and guarantee zero data leakage:
1. **Duplicate Elimination:** MD5 cryptographic hashes were calculated for each raw image. Identical and near-identical image files were purged prior to dataset splitting.
2. **Strict Split Isolation:** Data augmentation (random rotations, width/height shifts, zooms, flips) is applied strictly during training execution. Validation and testing subsets undergo zero augmentation.

---

## 5. Known Dataset Shortcuts and Biases
1. **Neutral Laboratory Backdrop Bias:** Leaves were excised and photographed on flat, artificial grey/black paper backdrops. In-field agricultural photography exhibits soil background, weeds, variable shadows, and canopy occlusion.
2. **Single Leaflet Isolation:** Symptoms on detached single leaflets obscure whether infection originated from the lower or upper canopy.
