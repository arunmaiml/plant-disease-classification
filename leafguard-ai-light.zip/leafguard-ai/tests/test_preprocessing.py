"""
LEAFGUARD AI - Automated Tests for Preprocessing and Dataset Integrity
"""
import os
import io
import json
import pytest
import numpy as np
from PIL import Image

import config
from ml.preprocess import preprocess_image_for_model


def test_class_names_mapping_exists():
    """Verify class_names.json is properly saved and contains 6 target classes."""
    assert os.path.exists(config.CLASS_NAMES_FILE), "class_names.json does not exist."
    with open(config.CLASS_NAMES_FILE, "r") as f:
        mapping = json.load(f)
    assert len(mapping) == 6, f"Expected 6 classes, got {len(mapping)}"
    # Verify all 6 target classes are present
    classes_present = set(mapping.values())
    for target in config.TARGET_CLASSES:
        assert target in classes_present, f"Missing target class {target}"


def test_preprocessing_valid_image():
    """Verify preprocessing produces expected tensor shape and normalization range."""
    # Create test RGB image
    img = Image.new("RGB", (300, 300), color=(100, 180, 80))
    buf = io.BytesIO()
    img.save(buf, format="JPEG")
    buf.seek(0)

    # Test MobileNetV2 preprocessing (scaled to [-1, 1])
    tensor, err = preprocess_image_for_model(buf, model_type="mobilenet")
    assert err is None, f"Preprocessing failed: {err}"
    assert tensor is not None
    assert tensor.shape == (1, config.IMG_HEIGHT, config.IMG_WIDTH, 3)
    assert np.min(tensor) >= -1.05 and np.max(tensor) <= 1.05

    # Test CNN preprocessing (scaled to [0, 1])
    buf.seek(0)
    tensor_cnn, err_cnn = preprocess_image_for_model(buf, model_type="cnn")
    assert err_cnn is None
    assert tensor_cnn is not None
    assert tensor_cnn.shape == (1, config.IMG_HEIGHT, config.IMG_WIDTH, 3)
    assert np.min(tensor_cnn) >= 0.0 and np.max(tensor_cnn) <= 1.0


def test_preprocessing_corrupted_bytes():
    """Verify corrupted bytes return an informative error."""
    corrupted_data = b"NOT_A_VALID_IMAGE_FILE_RANDOM_BYTES_123456"
    tensor, err = preprocess_image_for_model(corrupted_data)
    assert tensor is None
    assert err is not None
    assert "Failed to process image" in err


def test_preprocessing_too_small_image():
    """Verify that images smaller than 16x16 are rejected."""
    tiny_img = Image.new("RGB", (10, 10), color=(50, 120, 50))
    buf = io.BytesIO()
    tiny_img.save(buf, format="PNG")
    buf.seek(0)

    tensor, err = preprocess_image_for_model(buf)
    assert tensor is None
    assert "too small" in err.lower()
