"""
LEAFGUARD AI - Automated API & Integration Test Suite
Validates Flask endpoints, input validation, error handling, inference, and database persistence.
"""
import os
import io
import json
import pytest
from PIL import Image

import config
from app import app
from database import init_db, clear_history


@pytest.fixture
def client():
    app.config["TESTING"] = True
    with app.test_client() as client:
        init_db()
        yield client


def test_landing_page_route(client):
    """GET / returns HTTP 200 with title and key components."""
    response = client.get("/")
    assert response.status_code == 200
    html = response.data.decode("utf-8")
    assert "LeafGuard AI" in html
    assert "Understand Your Plant" in html
    assert "Analyze a Leaf" in html


def test_analyze_page_route(client):
    """GET /analyze returns HTTP 200."""
    response = client.get("/analyze")
    assert response.status_code == 200
    html = response.data.decode("utf-8")
    assert "Foliar Classification Workspace" in html
    assert "dropzone" in html


def test_dashboard_page_route(client):
    """GET /dashboard returns HTTP 200."""
    response = client.get("/dashboard")
    assert response.status_code == 200
    html = response.data.decode("utf-8")
    assert "Model Performance" in html


def test_limitations_page_route(client):
    """GET /limitations returns HTTP 200."""
    response = client.get("/limitations")
    assert response.status_code == 200
    html = response.data.decode("utf-8")
    assert "Dataset Provenance" in html
    assert "Diagnostic Limitation Notice" in html


def test_api_model_info(client):
    """GET /api/model-info returns active model metadata and supported classes."""
    response = client.get("/api/model-info")
    assert response.status_code == 200
    data = response.get_json()
    assert "model_loaded" in data
    assert data["model_loaded"] is True
    assert len(data["supported_classes"]) == 6
    assert data["input_dimensions"] == [224, 224, 3]


def test_api_evaluation(client):
    """GET /api/evaluation returns real measured metrics."""
    response = client.get("/api/evaluation")
    assert response.status_code == 200
    data = response.get_json()
    assert data["available"] is True
    assert "MobileNetV2" in data["data"]["models"]
    assert "charts" in data


def test_predict_missing_upload(client):
    """POST /api/predict without file returns 400."""
    response = client.post("/api/predict", data={})
    assert response.status_code == 400
    data = response.get_json()
    assert data["success"] is False
    assert "No image file provided" in data["error"]


def test_predict_unsupported_format(client):
    """POST /api/predict with unsupported extension (.pdf) returns 415."""
    data = {
        "file": (io.BytesIO(b"fake pdf content"), "document.pdf")
    }
    response = client.post("/api/predict", data=data, content_type="multipart/form-data")
    assert response.status_code == 415
    json_data = response.get_json()
    assert json_data["success"] is False
    assert "Unsupported file extension" in json_data["error"]


def test_predict_empty_file(client):
    """POST /api/predict with 0-byte file returns 400."""
    data = {
        "file": (io.BytesIO(b""), "leaf.jpg")
    }
    response = client.post("/api/predict", data=data, content_type="multipart/form-data")
    assert response.status_code == 400
    json_data = response.get_json()
    assert json_data["success"] is False
    assert "empty" in json_data["error"].lower()


def test_predict_success_with_real_image(client):
    """POST /api/predict with valid leaf image executes real inference."""
    # Create valid synthetic leaf image
    img = Image.new("RGB", (256, 256), color=(60, 140, 45))
    buf = io.BytesIO()
    img.save(buf, format="JPEG")
    buf.seek(0)

    data = {
        "file": (buf, "test_foliar_leaf.jpg")
    }
    response = client.post("/api/predict", data=data, content_type="multipart/form-data")
    assert response.status_code == 200
    json_data = response.get_json()
    assert json_data["success"] is True
    assert "predicted_class" in json_data
    assert json_data["predicted_class"] in config.TARGET_CLASSES
    assert "confidence" in json_data
    assert 0.0 <= json_data["confidence"] <= 1.0
    assert len(json_data["top_3_predictions"]) == 3
    assert "pathogen" in json_data
    assert "management" in json_data


def test_history_crud(client):
    """Tests GET and DELETE /api/history."""
    # Clear history first
    del_resp = client.delete("/api/history")
    assert del_resp.status_code == 200

    # Verify history is empty
    get_resp = client.get("/api/history")
    assert get_resp.status_code == 200
    assert len(get_resp.get_json()["history"]) == 0
