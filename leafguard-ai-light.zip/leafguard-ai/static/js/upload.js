/**
 * LEAFGUARD AI — Leaf Classification Workspace Controller
 * Handles drag-and-drop file ingestion, client validation, real model inference via REST,
 * result visualization, and SQLite history persistence.
 */
document.addEventListener("DOMContentLoaded", () => {
  const dropzone = document.getElementById("dropzone");
  const fileInput = document.getElementById("file-input");
  const previewContainer = document.getElementById("preview-container");
  const previewImg = document.getElementById("preview-img");
  const btnChangeImage = document.getElementById("btn-change-image");
  const btnRemoveImage = document.getElementById("btn-remove-image");
  const btnAnalyze = document.getElementById("btn-analyze");
  const btnAnalyzeText = document.getElementById("btn-analyze-text");
  const btnSpinner = document.getElementById("btn-spinner");
  const uploadError = document.getElementById("upload-error");

  const resultsEmpty = document.getElementById("results-empty");
  const resultsContent = document.getElementById("results-content");
  const resStatusBadge = document.getElementById("res-status-badge");
  const resModelBadge = document.getElementById("res-model-badge");
  const resClassTitle = document.getElementById("res-class-title");
  const resCropName = document.getElementById("res-crop-name");
  const resUncertaintyBox = document.getElementById("res-uncertainty-box");
  const resUncertaintyMsg = document.getElementById("res-uncertainty-message");
  const resConfidenceVal = document.getElementById("res-confidence-val");
  const resConfidenceFill = document.getElementById("res-confidence-fill");
  const resRankedList = document.getElementById("res-ranked-list");
  const resPathogen = document.getElementById("res-pathogen");
  const resSymptoms = document.getElementById("res-symptoms");
  const resManagement = document.getElementById("res-management");
  const btnReset = document.getElementById("btn-reset");

  const historyTbody = document.getElementById("history-tbody");
  const btnClearHistory = document.getElementById("btn-clear-history");

  let currentSelectedFile = null;

  const ALLOWED_EXTENSIONS = ["jpg", "jpeg", "png", "webp"];
  const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10MB

  function showError(msg) {
    uploadError.textContent = msg;
    uploadError.style.display = "block";
  }

  function clearError() {
    uploadError.textContent = "";
    uploadError.style.display = "none";
  }

  function validateFile(file) {
    if (!file) return "No file selected.";
    const ext = file.name.split(".").pop().toLowerCase();
    if (!ALLOWED_EXTENSIONS.includes(ext)) {
      return `Unsupported file format (.${ext}). Please upload JPG, JPEG, PNG, or WEBP.`;
    }
    if (file.size > MAX_FILE_SIZE) {
      return `File exceeds maximum 10MB limit (${(file.size / (1024 * 1024)).toFixed(1)}MB).`;
    }
    return null;
  }

  function handleFileSelection(file) {
    clearError();
    const err = validateFile(file);
    if (err) {
      showError(err);
      return;
    }

    currentSelectedFile = file;

    const reader = new FileReader();
    reader.onload = (e) => {
      previewImg.src = e.target.result;
      dropzone.style.display = "none";
      previewContainer.style.display = "block";
      btnAnalyze.disabled = false;
    };
    reader.readAsDataURL(file);
  }

  // Dropzone Events
  dropzone.addEventListener("click", () => fileInput.click());

  dropzone.addEventListener("dragover", (e) => {
    e.preventDefault();
    dropzone.classList.add("dragover");
  });

  dropzone.addEventListener("dragleave", () => {
    dropzone.classList.remove("dragover");
  });

  dropzone.addEventListener("drop", (e) => {
    e.preventDefault();
    dropzone.classList.remove("dragover");
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFileSelection(e.dataTransfer.files[0]);
    }
  });

  fileInput.addEventListener("change", (e) => {
    if (e.target.files && e.target.files.length > 0) {
      handleFileSelection(e.target.files[0]);
    }
  });

  btnChangeImage.addEventListener("click", () => fileInput.click());

  btnRemoveImage.addEventListener("click", () => {
    currentSelectedFile = null;
    fileInput.value = "";
    previewImg.src = "";
    previewContainer.style.display = "none";
    dropzone.style.display = "block";
    btnAnalyze.disabled = true;
    clearError();
  });

  // Sample Demonstration Leaves Picker
  document.querySelectorAll(".sample-pill").forEach(pill => {
    pill.addEventListener("click", async () => {
      clearError();
      const srcUrl = pill.getAttribute("data-src");
      const label = pill.getAttribute("data-label");
      try {
        const resp = await fetch(srcUrl);
        const blob = await resp.blob();
        const fname = srcUrl.split("/").pop() || "demo_leaf.jpg";
        const file = new File([blob], fname, { type: blob.type || "image/jpeg" });
        handleFileSelection(file);
      } catch (err) {
        showError(`Failed to load preset demo leaf: ${err.message}`);
      }
    });
  });

  // Analyze Button Submission
  btnAnalyze.addEventListener("click", async () => {
    if (!currentSelectedFile) {
      showError("Please select or drop an image file first.");
      return;
    }

    clearError();
    btnAnalyze.disabled = true;
    btnAnalyzeText.textContent = "Running Deep Inference...";
    btnSpinner.style.display = "inline-block";

    const formData = new FormData();
    formData.append("file", currentSelectedFile);

    try {
      const response = await fetch("/api/predict", {
        method: "POST",
        body: formData
      });

      const data = await response.json();

      if (!response.ok || !data.success) {
        throw new Error(data.error || "Inference server error.");
      }

      // Render Results
      renderPrediction(data);
      loadHistory(); // Refresh audit trail
    } catch (err) {
      showError(`Diagnostic Error: ${err.message}`);
    } finally {
      btnAnalyze.disabled = false;
      btnAnalyzeText.textContent = "Analyze Leaf Image";
      btnSpinner.style.display = "none";
    }
  });

  function renderPrediction(data) {
    resultsEmpty.style.display = "none";
    resultsContent.style.display = "block";

    // Status Badge
    resStatusBadge.textContent = `● ${data.status}`;
    resStatusBadge.className = `mockup-status ${data.status === 'Healthy' ? 'status-healthy' : 'status-diseased'}`;

    // Model Version Badge
    resModelBadge.textContent = data.model_version;

    // Titles
    resClassTitle.textContent = data.predicted_display;
    resCropName.textContent = `${data.crop} — Pathogen: ${data.pathogen}`;

    // Uncertainty Flag
    if (data.is_uncertain) {
      resUncertaintyBox.style.display = "flex";
      resUncertaintyMsg.textContent = data.uncertainty_message;
    } else {
      resUncertaintyBox.style.display = "none";
    }

    // Top Confidence
    resConfidenceVal.textContent = `${data.confidence_percent}%`;
    resConfidenceFill.style.width = `${data.confidence_percent}%`;

    // Ranked Probabilities (Top 3)
    resRankedList.innerHTML = "";
    data.top_3_predictions.forEach(item => {
      const itemRow = document.createElement("div");
      itemRow.className = "ranked-item";
      itemRow.innerHTML = `
        <div class="ranked-item-header">
          <span style="color: var(--text-primary); font-size: 0.82rem;">${item.display_name} (${item.status})</span>
          <span style="color: var(--forest-800); font-size: 0.82rem;">${item.percentage}%</span>
        </div>
        <div class="confidence-bar-bg" style="height: 6px;">
          <div class="confidence-bar-fill" style="width: ${item.percentage}%; background: ${item.status === 'Healthy' ? '#2A9D8F' : '#E76F51'};"></div>
        </div>
      `;
      resRankedList.appendChild(itemRow);
    });

    // Agronomic Pathology Details
    resPathogen.textContent = data.pathogen || "N/A";
    resSymptoms.textContent = data.symptoms || "None documented.";
    resManagement.textContent = data.management || "Consult regional extension agronomist.";

    // Smooth scroll to results on mobile
    if (window.innerWidth < 900) {
      resultsContent.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  }

  // Reset Button
  btnReset.addEventListener("click", () => {
    currentSelectedFile = null;
    fileInput.value = "";
    previewImg.src = "";
    previewContainer.style.display = "none";
    dropzone.style.display = "block";
    btnAnalyze.disabled = true;
    resultsContent.style.display = "none";
    resultsEmpty.style.display = "block";
    clearError();
  });

  // History Functions
  async function loadHistory() {
    try {
      const res = await fetch("/api/history?limit=15");
      const data = await res.json();
      if (!data.success || data.history.length === 0) {
        historyTbody.innerHTML = `
          <tr>
            <td colspan="8" style="text-align: center; color: var(--text-muted); padding: 2rem;">No past predictions recorded yet.</td>
          </tr>
        `;
        return;
      }

      historyTbody.innerHTML = "";
      data.history.forEach(item => {
        const tr = document.createElement("tr");
        tr.innerHTML = `
          <td>#${item.id}</td>
          <td style="font-family: var(--font-mono); font-size: 0.78rem;">${item.timestamp}</td>
          <td>${item.crop.split('(')[0]}</td>
          <td><strong>${item.predicted_display}</strong></td>
          <td><span class="mockup-status ${item.status === 'Healthy' ? 'status-healthy' : 'status-diseased'}">${item.status}</span></td>
          <td><strong>${item.probability}%</strong></td>
          <td style="font-size: 0.76rem; color: var(--text-muted);">${item.model_version.split('(')[0]}</td>
          <td>${item.is_uncertain ? '<span style="color: #B45309; font-weight: 700;">⚠️ Low Conf</span>' : '<span style="color: #2D6A4F;">✓ Valid</span>'}</td>
        `;
        historyTbody.appendChild(tr);
      });
    } catch (err) {
      console.error("Failed loading history:", err);
    }
  }

  // Clear History
  btnClearHistory.addEventListener("click", async () => {
    if (confirm("Are you sure you want to delete all stored classification history?")) {
      try {
        await fetch("/api/history", { method: "DELETE" });
        loadHistory();
      } catch (err) {
        alert("Failed to clear history: " + err.message);
      }
    }
  });

  // Initial load
  loadHistory();
});
