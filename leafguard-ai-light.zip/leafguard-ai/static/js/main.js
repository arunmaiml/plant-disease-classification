/**
 * LEAFGUARD AI — Main Client Script
 * Handles global interactions and navigation aesthetics.
 */
document.addEventListener("DOMContentLoaded", () => {
  const navbar = document.getElementById("navbar");

  // Sticky navbar shadow on scroll
  window.addEventListener("scroll", () => {
    if (window.scrollY > 20) {
      navbar.style.boxShadow = "0 4px 20px rgba(8, 28, 21, 0.08)";
    } else {
      navbar.style.boxShadow = "none";
    }
  });

  // Smooth anchor scrolling
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener("click", function(e) {
      const targetId = this.getAttribute("href");
      if (targetId.length > 1) {
        const targetElem = document.querySelector(targetId);
        if (targetElem) {
          e.preventDefault();
          targetElem.scrollIntoView({ behavior: "smooth", block: "start" });
        }
      }
    });
  });
});
