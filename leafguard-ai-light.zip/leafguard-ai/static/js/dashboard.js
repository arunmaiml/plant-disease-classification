/**
 * LEAFGUARD AI — Model Evaluation Dashboard Controller
 * Fetches genuine measured artifacts from /api/evaluation, populates comparison metrics,
 * per-class performance tables, and renders misclassification sample cards.
 */
document.addEventListener("DOMContentLoaded", async () => {
  const evalStatusMsg = document.getElementById("eval-status-msg");
  const evalStatusText = document.getElementById("eval-status-text");

  const statMobAcc = document.getElementById("stat-mob-acc");
  const statMobF1 = document.getElementById("stat-mob-f1");
  const statCnnAcc = document.getElementById("stat-cnn-acc");

  const cmpMobAcc = document.getElementById("cmp-mob-acc");
  const cmpMobP = document.getElementById("cmp-mob-p");
  const cmpMobR = document.getElementById("cmp-mob-r");
  const cmpMobF1 = document.getElementById("cmp-mob-f1");
  const cmpMobWf1 = document.getElementById("cmp-mob-wf1");

  const cmpCnnAcc = document.getElementById("cmp-cnn-acc");
  const cmpCnnP = document.getElementById("cmp-cnn-p");
  const cmpCnnR = document.getElementById("cmp-cnn-r");
  const cmpCnnF1 = document.getElementById("cmp-cnn-f1");
  const cmpCnnWf1 = document.getElementById("cmp-cnn-wf1");

  const perClassTbody = document.getElementById("per-class-tbody");
  const errorGallery = document.getElementById("error-gallery-container");

  try {
    const res = await fetch("/api/evaluation");
    const json = await res.json();

    if (!json.available || !json.data) {
      evalStatusMsg.style.display = "block";
      evalStatusText.textContent = json.message || "Evaluation artifacts not available yet. Please execute 'python ml/evaluate.py'.";
      return;
    }

    const data = json.data;
    const mob = data.models.MobileNetV2;
    const cnn = data.models.Baseline_CNN;

    // Stat Cards
    if (mob) {
      statMobAcc.textContent = `${(mob.accuracy * 100).toFixed(1)}%`;
      statMobF1.textContent = `${(mob.macro_f1 * 100).toFixed(1)}%`;

      cmpMobAcc.textContent = `${(mob.accuracy * 100).toFixed(1)}%`;
      cmpMobP.textContent = `${(mob.macro_precision * 100).toFixed(1)}%`;
      cmpMobR.textContent = `${(mob.macro_recall * 100).toFixed(1)}%`;
      cmpMobF1.textContent = `${(mob.macro_f1 * 100).toFixed(1)}%`;
      cmpMobWf1.textContent = `${(mob.weighted_f1 * 100).toFixed(1)}%`;
    }

    if (cnn) {
      statCnnAcc.textContent = `${(cnn.accuracy * 100).toFixed(1)}%`;

      cmpCnnAcc.textContent = `${(cnn.accuracy * 100).toFixed(1)}%`;
      cmpCnnP.textContent = `${(cnn.macro_precision * 100).toFixed(1)}%`;
      cmpCnnR.textContent = `${(cnn.macro_recall * 100).toFixed(1)}%`;
      cmpCnnF1.textContent = `${(cnn.macro_f1 * 100).toFixed(1)}%`;
      cmpCnnWf1.textContent = `${(cnn.weighted_f1 * 100).toFixed(1)}%`;
    }

    // Per-Class Table
    if (mob && mob.per_class) {
      perClassTbody.innerHTML = "";
      Object.entries(mob.per_class).forEach(([clsKey, item]) => {
        const crop = clsKey.startsWith("Potato") ? "Potato (Solanum tuberosum)" : "Tomato (Solanum lycopersicum)";
        const tr = document.createElement("tr");
        tr.innerHTML = `
          <td><strong>${item.display_name}</strong></td>
          <td>${crop}</td>
          <td>${(item.precision * 100).toFixed(1)}%</td>
          <td>${(item.recall * 100).toFixed(1)}%</td>
          <td><strong style="color: var(--forest-800);">${(item.f1_score * 100).toFixed(1)}%</strong></td>
          <td>${item.support} test leaves</td>
        `;
        perClassTbody.appendChild(tr);
      });
    }

    // Error & Confusion Sample Cards
    if (data.error_samples && data.error_samples.length > 0) {
      errorGallery.innerHTML = "";
      data.error_samples.forEach(sample => {
        const card = document.createElement("div");
        card.style.background = "var(--bg-card-subtle)";
        card.style.border = "1px solid var(--border-light)";
        card.style.borderRadius = "var(--radius-md)";
        card.style.padding = "1rem";

        card.innerHTML = `
          <div style="font-size: 0.74rem; font-family: var(--font-mono); color: var(--text-muted); margin-bottom: 0.4rem; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
            File: ${sample.filename}
          </div>
          <div style="font-size: 0.82rem; margin-bottom: 0.3rem;">
            <span style="color: var(--text-muted); font-weight: 700;">Ground Truth:</span>
            <strong style="color: var(--forest-800);">${sample.true_display}</strong>
          </div>
          <div style="font-size: 0.82rem; margin-bottom: 0.5rem;">
            <span style="color: var(--accent-alert); font-weight: 700;">Model Predicted:</span>
            <strong style="color: var(--accent-alert);">${sample.pred_display}</strong>
          </div>
          <div style="font-size: 0.78rem; color: var(--text-muted);">
            Confidence: <strong>${(sample.confidence * 100).toFixed(1)}%</strong>
          </div>
        `;
        errorGallery.appendChild(card);
      });
    } else {
      errorGallery.innerHTML = `
        <div style="grid-column: 1 / -1; text-align: center; color: var(--sage-500); padding: 1.5rem; font-weight: 600;">
          Zero errors detected on evaluated test samples.
        </div>
      `;
    }

  } catch (err) {
    console.error("Dashboard metric error:", err);
    evalStatusMsg.style.display = "block";
    evalStatusText.textContent = "Failed connecting to evaluation API.";
  }
});
