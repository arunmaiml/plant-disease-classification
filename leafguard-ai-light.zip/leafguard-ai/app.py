"""
LEAFGUARD AI - Flask Web Application & REST API
Intelligent Plant Leaf Disease Classification System
"""
import os
import sys
import json
import base64
from flask import Flask, render_template, request, jsonify, send_from_directory
from werkzeug.utils import secure_filename

import config
from database import init_db, record_prediction, fetch_history, clear_history
from ml.predict import LeafPredictor

# Initialize Flask app
app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = config.MAX_CONTENT_LENGTH

# Initialize Database
init_db()

# Lazy-load Predictor singleton
predictor = LeafPredictor.get_instance()


def allowed_file(filename: str) -> bool:
    """Checks if file extension is allowed."""
    return "." in filename and filename.rsplit(".", 1)[1].lower() in config.ALLOWED_EXTENSIONS


# ==================== HTML PAGE ROUTES ====================

@app.route("/")
def index():
    """Page 1: Landing Page."""
    return render_template("index.html", supported_classes=config.CLASS_METADATA)


@app.route("/analyze")
def analyze():
    """Page 2 & 3: Disease Classification Workspace & Live Prediction Panel."""
    # List available sample demo leaves for easy one-click testing
    demo_leaves = []
    if os.path.exists(config.SAMPLE_IMAGES_DIR):
        for f in os.listdir(config.SAMPLE_IMAGES_DIR):
            if f.lower().endswith(('.jpg', '.jpeg', '.png')):
                c_name = f.replace("_demo.jpg", "").replace("_demo.png", "")
                meta = config.CLASS_METADATA.get(c_name, {})
                demo_leaves.append({
                    "filename": f,
                    "url": f"/static/images/sample_leaves/{f}",
                    "crop": meta.get("crop", "Solanaceae"),
                    "condition": meta.get("condition", c_name.replace("___", " - "))
                })

    return render_template("analyze.html", demo_leaves=demo_leaves, supported_classes=config.CLASS_METADATA)


@app.route("/dashboard")
def dashboard():
    """Page 4: Model Performance Dashboard."""
    return render_template("dashboard.html")


@app.route("/limitations")
def limitations():
    """Page 5: Dataset & Limitations."""
    return render_template("limitations.html", classes_meta=config.CLASS_METADATA)


# ==================== REST API ENDPOINTS ====================

@app.route("/api/predict", methods=["POST"])
def api_predict():
    """
    Accepts an uploaded leaf image, validates format/dimensions,
    performs real model inference, logs to history, and returns structured JSON.
    """
    if "file" not in request.files and "image_data" not in request.form:
        return jsonify({
            "success": False,
            "error": "No image file provided in request."
        }), 400

    image_source = None

    if "file" in request.files:
        file = request.files["file"]
        if file.filename == "":
            return jsonify({
                "success": False,
                "error": "No file selected."
            }), 400

        if not allowed_file(file.filename):
            return jsonify({
                "success": False,
                "error": f"Unsupported file extension. Allowed formats: {', '.join(config.ALLOWED_EXTENSIONS)}"
            }), 415

        # Read into memory
        image_source = file.read()
        if len(image_source) == 0:
            return jsonify({
                "success": False,
                "error": "Uploaded image file is empty."
            }), 400

    elif "image_data" in request.form:
        # Base64 string fallback
        raw_b64 = request.form["image_data"]
        if "," in raw_b64:
            raw_b64 = raw_b64.split(",", 1)[1]
        try:
            image_source = base64.b64decode(raw_b64)
        except Exception:
            return jsonify({
                "success": False,
                "error": "Malformed base64 image data."
            }), 400

    # Run inference
    result = predictor.predict(image_source)

    if not result.get("success", False):
        return jsonify(result), 500

    # Record in SQLite history (no image file stored on disk for privacy)
    record_prediction(
        predicted_class=result["predicted_class"],
        predicted_display=result["predicted_display"],
        crop=result["crop"],
        status=result["status"],
        probability=result["confidence"],
        model_version=result["model_version"],
        is_uncertain=result["is_uncertain"]
    )

    return jsonify(result), 200


@app.route("/api/model-info", methods=["GET"])
def api_model_info():
    """Returns active model metadata, supported classes, and load status."""
    info = predictor.get_info()
    return jsonify(info), 200


@app.route("/api/evaluation", methods=["GET"])
def api_evaluation():
    """Returns model evaluation metrics and chart paths if available."""
    if not os.path.exists(config.EVALUATION_METRICS_PATH):
        return jsonify({
            "available": False,
            "message": "Evaluation artifacts have not been generated yet. Please run 'python ml/evaluate.py'."
        }), 200

    try:
        with open(config.EVALUATION_METRICS_PATH, "r") as f:
            data = json.load(f)
        return jsonify({
            "available": True,
            "data": data,
            "charts": {
                "confusion_matrix": "/artifacts/confusion_matrix.png",
                "cnn_curves": "/artifacts/training_curves_cnn.png",
                "mobilenet_curves": "/artifacts/training_curves_mobilenet.png",
                "model_comparison": "/artifacts/model_comparison.png",
                "class_distribution": "/artifacts/class_distribution.png"
            }
        }), 200
    except Exception as e:
        return jsonify({
            "available": False,
            "error": f"Failed reading evaluation artifacts: {str(e)}"
        }), 500


@app.route("/api/history", methods=["GET", "DELETE"])
def api_history():
    """Fetches or clears prediction history."""
    if request.method == "GET":
        limit = request.args.get("limit", default=25, type=int)
        history = fetch_history(limit=limit)
        return jsonify({"success": True, "count": len(history), "history": history}), 200

    elif request.method == "DELETE":
        success = clear_history()
        return jsonify({"success": success, "message": "Prediction history deleted successfully."}), 200


@app.route("/artifacts/<path:filename>")
def serve_artifacts(filename):
    """Serves generated chart images safely."""
    return send_from_directory(config.ARTIFACTS_DIR, filename)


# ==================== ERROR HANDLERS ====================

@app.errorhandler(413)
def request_entity_too_large(error):
    return jsonify({
        "success": False,
        "error": f"Uploaded file exceeds the maximum permitted size limit of {config.MAX_CONTENT_LENGTH // (1024 * 1024)}MB."
    }), 413


@app.errorhandler(404)
def not_found(error):
    if request.path.startswith("/api/"):
        return jsonify({"success": False, "error": "Endpoint not found."}), 404
    return render_template("index.html"), 404


@app.errorhandler(500)
def internal_server_error(error):
    return jsonify({"success": False, "error": "An internal server error occurred."}), 500


if __name__ == "__main__":
    print("[LeafGuard AI] Starting server at http://127.0.0.1:5000 ...")
    app.run(host="0.0.0.0", port=5000, debug=False)
