"""
LEAFGUARD AI - Configuration Module
Intelligent Plant Leaf Disease Classification System
"""
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Data Paths
DATA_DIR = os.path.join(BASE_DIR, "data")
SAMPLE_DATASET_DIR = os.path.join(DATA_DIR, "sample_dataset")
RAW_DATASET_DIR = os.path.join(DATA_DIR, "raw")

# Model and Artifact Paths
MODELS_DIR = os.path.join(BASE_DIR, "models")
ARTIFACTS_DIR = os.path.join(BASE_DIR, "artifacts")
CLASS_NAMES_FILE = os.path.join(MODELS_DIR, "class_names.json")
BASELINE_MODEL_PATH = os.path.join(MODELS_DIR, "baseline_cnn.keras")
MOBILENET_MODEL_PATH = os.path.join(MODELS_DIR, "mobilenetv2_leafguard.keras")
EVALUATION_METRICS_PATH = os.path.join(ARTIFACTS_DIR, "evaluation_metrics.json")

# Database Path
DB_PATH = os.path.join(BASE_DIR, "leafguard_history.db")

# Static / Sample Uploads
STATIC_DIR = os.path.join(BASE_DIR, "static")
SAMPLE_IMAGES_DIR = os.path.join(STATIC_DIR, "images", "sample_leaves")
UPLOAD_FOLDER = os.path.join(BASE_DIR, "uploads")

# Model Hyperparameters
IMG_HEIGHT = 224
IMG_WIDTH = 224
IMG_CHANNELS = 3
BATCH_SIZE = 16
RANDOM_SEED = 42

# Training Configuration
CNN_EPOCHS = 8
MOBILENET_EPOCHS = 10
LEARNING_RATE = 0.001

# Inference Uncertainty Threshold (if max class prob < threshold, raise uncertainty notice)
UNCERTAINTY_THRESHOLD = 0.65

# Selected Target Classes from PlantVillage Benchmark
# Solanaceae family: Tomato and Potato - early blight, late blight, and healthy
TARGET_CLASSES = [
    "Potato___Early_blight",
    "Potato___Late_blight",
    "Potato___healthy",
    "Tomato___Early_blight",
    "Tomato___Late_blight",
    "Tomato___healthy"
]

# Agronomic & Botanical Metadata for Supported Classes
CLASS_METADATA = {
    "Potato___Early_blight": {
        "crop": "Potato (Solanum tuberosum)",
        "condition": "Early Blight",
        "pathogen": "Alternaria solani (Fungus)",
        "status": "Diseased",
        "symptoms": "Dark brown to black necrotic spots with concentric rings (target-board pattern), primarily starting on mature lower foliage.",
        "description": "A destructive fungal pathogen widespread in potato cultivation causing premature defoliation and yield reduction under warm, humid conditions.",
        "management": "Rotate crops, eliminate volunteer potato plants, avoid overhead sprinkler irrigation, and consult extension agronomists."
    },
    "Potato___Late_blight": {
        "crop": "Potato (Solanum tuberosum)",
        "condition": "Late Blight",
        "pathogen": "Phytophthora infestans (Oomycete)",
        "status": "Diseased",
        "symptoms": "Water-soaked, dark green to purplish-black lesions with pale green halos, often accompanied by white mycelial fuzz on leaf undersides in high humidity.",
        "description": "Historic disease responsible for the 1840s Irish Potato Famine; rapidly destroys foliage and infects tubers under cool, damp conditions.",
        "management": "Plant certified disease-free seed tubers, ensure rapid canopy drying, monitor regional late-blight forecast alerts."
    },
    "Potato___healthy": {
        "crop": "Potato (Solanum tuberosum)",
        "condition": "Healthy Foliage",
        "pathogen": "None detected",
        "status": "Healthy",
        "symptoms": "Vibrant, uniformly green pinnate foliage with smooth texture, free of visible chlorosis, lesions, or necrosis.",
        "description": "The leaf exhibits typical morphology of healthy vegetative potato growth with no apparent symptom of foliar infection.",
        "management": "Continue balanced fertilization, regular scout monitoring, and optimal irrigation practices."
    },
    "Tomato___Early_blight": {
        "crop": "Tomato (Solanum lycopersicum)",
        "condition": "Early Blight",
        "pathogen": "Alternaria solani (Fungus)",
        "status": "Diseased",
        "symptoms": "Concentric dark brown circular spots (target lesions) surrounded by chlorotic yellow halos, causing lower leaf yellowing and senescence.",
        "description": "Common foliar affliction affecting tomatoes globally, overwintering on crop debris and splashing onto lower stems and leaves during rainfall.",
        "management": "Stake and prune lower leaves for air circulation, mulch soil surface to prevent spore splash, practice 3-year crop rotation."
    },
    "Tomato___Late_blight": {
        "crop": "Tomato (Solanum lycopersicum)",
        "condition": "Late Blight",
        "pathogen": "Phytophthora infestans (Oomycete)",
        "status": "Diseased",
        "symptoms": "Large, irregular water-soaked greasy lesions turning dark brown to black, rapid defoliation, and fruit rot in wet weather.",
        "description": "Highly contagious oomycete capable of destroying entire tomato stands within days during prolonged periods of cool, wet weather.",
        "management": "Remove and safely destroy heavily infected plants, ensure wide plant spacing, monitor weather station alerts."
    },
    "Tomato___healthy": {
        "crop": "Tomato (Solanum lycopersicum)",
        "condition": "Healthy Foliage",
        "pathogen": "None detected",
        "status": "Healthy",
        "symptoms": "Uniform deep green coloration, intact glandular trichomes, well-formed leaf margins without spots, curling, or discoloration.",
        "description": "Leaf shows normal physiological characteristics of a healthy tomato vine in good vegetative health.",
        "management": "Maintain consistent drip irrigation, balanced nitrogen/calcium supply, and routine scouting."
    }
}

# Upload Constraints
MAX_CONTENT_LENGTH = 10 * 1024 * 1024  # 10 MB limit
ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "webp"}
