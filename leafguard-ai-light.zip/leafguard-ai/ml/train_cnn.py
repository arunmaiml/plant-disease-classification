"""
LEAFGUARD AI - Baseline CNN Classifier Training
Builds, trains, and saves a custom Convolutional Neural Network baseline.
Saves class_names.json mapping and training history for model comparison.
"""
import os
import sys
import json
import time
import tensorflow as tf
from tensorflow.keras import layers, models, optimizers

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import config
from ml.preprocess import get_data_generators


def build_baseline_cnn(input_shape=(config.IMG_HEIGHT, config.IMG_WIDTH, 3), num_classes=len(config.TARGET_CLASSES)):
    """
    Constructs a 3-block convolutional neural network baseline.
    Architecture:
      Conv2D(32, 3x3) -> MaxPool -> Conv2D(64, 3x3) -> MaxPool -> Conv2D(128, 3x3) -> MaxPool
      Flatten -> Dense(128, ReLU) -> Dropout(0.4) -> Dense(num_classes, Softmax)
    """
    model = models.Sequential([
        layers.Input(shape=input_shape),
        layers.Conv2D(32, (3, 3), activation="relu", padding="same", name="conv1"),
        layers.MaxPooling2D((2, 2), name="pool1"),

        layers.Conv2D(64, (3, 3), activation="relu", padding="same", name="conv2"),
        layers.MaxPooling2D((2, 2), name="pool2"),

        layers.Conv2D(128, (3, 3), activation="relu", padding="same", name="conv3"),
        layers.MaxPooling2D((2, 2), name="pool3"),

        layers.Flatten(name="flatten"),
        layers.Dense(128, activation="relu", name="dense1"),
        layers.Dropout(0.4, name="dropout"),
        layers.Dense(num_classes, activation="softmax", name="output_classes")
    ], name="Baseline_CNN")

    model.compile(
        optimizer=optimizers.Adam(learning_rate=config.LEARNING_RATE),
        loss="categorical_crossentropy",
        metrics=["accuracy"]
    )
    return model


def train_baseline_cnn():
    os.makedirs(config.MODELS_DIR, exist_ok=True)
    os.makedirs(config.ARTIFACTS_DIR, exist_ok=True)

    print("[CNN Baseline] Initializing data generators...")
    train_gen, val_gen, test_gen = get_data_generators(model_type="cnn")

    # Save class names mapping
    class_indices = train_gen.class_indices
    # Invert to index -> class_name
    index_to_class = {v: k for k, v in class_indices.items()}
    with open(config.CLASS_NAMES_FILE, "w") as f:
        json.dump(index_to_class, f, indent=2)
    print(f"[CNN Baseline] Saved class mapping to {config.CLASS_NAMES_FILE}")

    model = build_baseline_cnn(num_classes=len(class_indices))
    model.summary()

    print(f"[CNN Baseline] Training for {config.CNN_EPOCHS} epochs...")
    start_time = time.time()
    history = model.fit(
        train_gen,
        validation_data=val_gen,
        epochs=config.CNN_EPOCHS,
        verbose=1
    )
    training_time = round(time.time() - start_time, 2)
    print(f"[CNN Baseline] Training completed in {training_time}s.")

    # Save trained baseline model
    model.save(config.BASELINE_MODEL_PATH)
    print(f"[CNN Baseline] Saved model to {config.BASELINE_MODEL_PATH}")

    # Save history
    history_dict = {
        "epochs": list(range(1, config.CNN_EPOCHS + 1)),
        "accuracy": [float(x) for x in history.history["accuracy"]],
        "val_accuracy": [float(x) for x in history.history["val_accuracy"]],
        "loss": [float(x) for x in history.history["loss"]],
        "val_loss": [float(x) for x in history.history["val_loss"]],
        "training_time_seconds": training_time
    }
    history_file = os.path.join(config.ARTIFACTS_DIR, "cnn_history.json")
    with open(history_file, "w") as f:
        json.dump(history_dict, f, indent=2)

    return model, history_dict


if __name__ == "__main__":
    train_baseline_cnn()
