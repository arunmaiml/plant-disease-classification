"""
LEAFGUARD AI - Model Evaluation & Error Analysis Module
Evaluates both Baseline CNN and MobileNetV2 on the held-out test split.
Computes comprehensive classification metrics, confusion matrices, error samples,
and exports high-quality visualization figures for presentations and the web dashboard.
"""
import os
import sys
import json
import numpy as np
import matplotlib
matplotlib.use("Agg")  # Non-interactive backend
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import (
    accuracy_score, precision_recall_fscore_support,
    confusion_matrix, classification_report
)
import tensorflow as tf

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import config
from ml.preprocess import preprocess_image_for_model


def load_test_dataset():
    """
    Loads all images, labels, and file paths from the held-out test split.
    """
    test_dir = os.path.join(config.SAMPLE_DATASET_DIR, "test")
    with open(config.CLASS_NAMES_FILE, "r") as f:
        idx_to_class = json.load(f)
    # Ensure keys are ints
    idx_to_class = {int(k): v for k, v in idx_to_class.items()}
    class_to_idx = {v: k for k, v in idx_to_class.items()}

    file_paths = []
    y_true = []

    for class_name, cls_idx in class_to_idx.items():
        cls_dir = os.path.join(test_dir, class_name)
        if not os.path.exists(cls_dir):
            continue
        for fname in os.listdir(cls_dir):
            if fname.lower().endswith(('.jpg', '.jpeg', '.png')):
                fpath = os.path.join(cls_dir, fname)
                file_paths.append(fpath)
                y_true.append(cls_idx)

    return file_paths, np.array(y_true), idx_to_class, class_to_idx


def evaluate_single_model(model, file_paths, y_true, model_type="mobilenet"):
    """Runs inference on all test files and returns predictions and predicted probabilities."""
    y_pred = []
    y_probs = []

    for fpath in file_paths:
        tensor, err = preprocess_image_for_model(fpath, model_type=model_type)
        if err or tensor is None:
            # Fallback uniform
            probs = np.ones((len(config.TARGET_CLASSES),)) / len(config.TARGET_CLASSES)
        else:
            probs = model.predict(tensor, verbose=0)[0]
        pred_class = int(np.argmax(probs))
        y_pred.append(pred_class)
        y_probs.append(probs)

    y_pred = np.array(y_pred)
    y_probs = np.array(y_probs)
    return y_pred, y_probs


def run_evaluation():
    os.makedirs(config.ARTIFACTS_DIR, exist_ok=True)
    file_paths, y_true, idx_to_class, class_to_idx = load_test_dataset()
    class_labels = [idx_to_class[i] for i in range(len(idx_to_class))]
    display_labels = [c.replace("___", " - ").replace("_", " ") for c in class_labels]

    print(f"[Evaluation] Loaded {len(file_paths)} test images across {len(class_labels)} classes.")

    # 1. Load Trained Models
    has_cnn = os.path.exists(config.BASELINE_MODEL_PATH)
    has_mobilenet = os.path.exists(config.MOBILENET_MODEL_PATH)

    if not has_cnn and not has_mobilenet:
        print("[Evaluation] Error: No trained models found in models/ directory.")
        return None

    results = {
        "dataset_summary": {
            "test_images_count": len(file_paths),
            "classes": class_labels,
            "class_display_names": display_labels
        },
        "models": {},
        "comparison": {}
    }

    # Evaluate Baseline CNN
    cnn_pred = None
    if has_cnn:
        print("[Evaluation] Evaluating Baseline CNN...")
        cnn_model = tf.keras.models.load_model(config.BASELINE_MODEL_PATH)
        cnn_pred, cnn_probs = evaluate_single_model(cnn_model, file_paths, y_true, model_type="cnn")
        cnn_acc = float(accuracy_score(y_true, cnn_pred))
        p_macro, r_macro, f1_macro, _ = precision_recall_fscore_support(y_true, cnn_pred, average="macro", zero_division=0)
        p_wt, r_wt, f1_wt, _ = precision_recall_fscore_support(y_true, cnn_pred, average="weighted", zero_division=0)
        p_cls, r_cls, f1_cls, supp_cls = precision_recall_fscore_support(y_true, cnn_pred, average=None, zero_division=0)

        cnn_cm = confusion_matrix(y_true, cnn_pred, labels=list(range(len(class_labels))))

        results["models"]["Baseline_CNN"] = {
            "accuracy": round(cnn_acc, 4),
            "macro_precision": round(float(p_macro), 4),
            "macro_recall": round(float(r_macro), 4),
            "macro_f1": round(float(f1_macro), 4),
            "weighted_f1": round(float(f1_wt), 4),
            "per_class": {
                class_labels[i]: {
                    "display_name": display_labels[i],
                    "precision": round(float(p_cls[i]), 4),
                    "recall": round(float(r_cls[i]), 4),
                    "f1_score": round(float(f1_cls[i]), 4),
                    "support": int(supp_cls[i])
                } for i in range(len(class_labels))
            },
            "confusion_matrix": cnn_cm.tolist()
        }

    # Evaluate MobileNetV2
    mob_pred = None
    if has_mobilenet:
        print("[Evaluation] Evaluating MobileNetV2 Transfer Learning Model...")
        mob_model = tf.keras.models.load_model(config.MOBILENET_MODEL_PATH)
        mob_pred, mob_probs = evaluate_single_model(mob_model, file_paths, y_true, model_type="mobilenet")
        mob_acc = float(accuracy_score(y_true, mob_pred))
        p_macro, r_macro, f1_macro, _ = precision_recall_fscore_support(y_true, mob_pred, average="macro", zero_division=0)
        p_wt, r_wt, f1_wt, _ = precision_recall_fscore_support(y_true, mob_pred, average="weighted", zero_division=0)
        p_cls, r_cls, f1_cls, supp_cls = precision_recall_fscore_support(y_true, mob_pred, average=None, zero_division=0)

        mob_cm = confusion_matrix(y_true, mob_pred, labels=list(range(len(class_labels))))

        results["models"]["MobileNetV2"] = {
            "accuracy": round(mob_acc, 4),
            "macro_precision": round(float(p_macro), 4),
            "macro_recall": round(float(r_macro), 4),
            "macro_f1": round(float(f1_macro), 4),
            "weighted_f1": round(float(f1_wt), 4),
            "per_class": {
                class_labels[i]: {
                    "display_name": display_labels[i],
                    "precision": round(float(p_cls[i]), 4),
                    "recall": round(float(r_cls[i]), 4),
                    "f1_score": round(float(f1_cls[i]), 4),
                    "support": int(supp_cls[i])
                } for i in range(len(class_labels))
            },
            "confusion_matrix": mob_cm.tolist()
        }

    # Error analysis and sample selection (from primary MobileNetV2 model or CNN)
    active_pred = mob_pred if mob_pred is not None else cnn_pred
    active_probs = mob_probs if mob_probs is not None else cnn_probs
    correct_samples = []
    error_samples = []
    confusion_pairs = {}

    for idx, (path, true_cls, pred_cls, probs) in enumerate(zip(file_paths, y_true, active_pred, active_probs)):
        fname = os.path.basename(path)
        item = {
            "filename": fname,
            "filepath": path,
            "true_class": class_labels[true_cls],
            "true_display": display_labels[true_cls],
            "pred_class": class_labels[pred_cls],
            "pred_display": display_labels[pred_cls],
            "confidence": round(float(probs[pred_cls]), 4),
            "is_correct": bool(true_cls == pred_cls)
        }
        if true_cls == pred_cls and len(correct_samples) < 6:
            correct_samples.append(item)
        elif true_cls != pred_cls and len(error_samples) < 6:
            error_samples.append(item)

        if true_cls != pred_cls:
            pair = f"{display_labels[true_cls]} -> {display_labels[pred_cls]}"
            confusion_pairs[pair] = confusion_pairs.get(pair, 0) + 1

    results["correct_samples"] = correct_samples
    results["error_samples"] = error_samples
    results["confusion_analysis"] = sorted(confusion_pairs.items(), key=lambda x: x[1], reverse=True)

    # ------------------ GENERATE CHARTS ------------------
    # Chart styling: Botanical Theme
    sns.set_theme(style="whitegrid", font="sans-serif")
    palette_botanical = ["#1B4332", "#2D6A4F", "#40916C", "#52B788", "#74C69D", "#95D5B2"]

    # 1. Confusion Matrix Chart
    if has_mobilenet:
        plt.figure(figsize=(9, 7))
        cm_data = np.array(results["models"]["MobileNetV2"]["confusion_matrix"])
        sns.heatmap(
            cm_data,
            annot=True,
            fmt="d",
            cmap="Greens",
            xticklabels=[c.replace("Potato___", "Pot: ").replace("Tomato___", "Tom: ") for c in class_labels],
            yticklabels=[c.replace("Potato___", "Pot: ").replace("Tomato___", "Tom: ") for c in class_labels],
            cbar=True
        )
        plt.title("LeafGuard AI - MobileNetV2 Confusion Matrix (Test Split)", fontsize=13, fontweight="bold", pad=12, color="#1B4332")
        plt.xlabel("Predicted Category", fontsize=11, fontweight="bold")
        plt.ylabel("Actual Ground Truth", fontsize=11, fontweight="bold")
        plt.xticks(rotation=30, ha="right")
        plt.tight_layout()
        cm_path = os.path.join(config.ARTIFACTS_DIR, "confusion_matrix.png")
        plt.savefig(cm_path, dpi=200)
        plt.close()
        print(f"[Evaluation] Saved {cm_path}")

    # 2. Training Curves - Baseline CNN
    cnn_hist_path = os.path.join(config.ARTIFACTS_DIR, "cnn_history.json")
    if os.path.exists(cnn_hist_path):
        with open(cnn_hist_path, "r") as f:
            chist = json.load(f)
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4.5))
        ax1.plot(chist["epochs"], chist["accuracy"], "o-", color="#2D6A4F", label="Train Accuracy", linewidth=2)
        ax1.plot(chist["epochs"], chist["val_accuracy"], "s--", color="#E76F51", label="Validation Accuracy", linewidth=2)
        ax1.set_title("Baseline CNN - Accuracy Curve", fontweight="bold", color="#1B4332")
        ax1.set_xlabel("Epoch")
        ax1.set_ylabel("Accuracy")
        ax1.legend(loc="lower right")
        ax1.set_ylim([0, 1.05])

        ax2.plot(chist["epochs"], chist["loss"], "o-", color="#2D6A4F", label="Train Loss", linewidth=2)
        ax2.plot(chist["epochs"], chist["val_loss"], "s--", color="#E76F51", label="Validation Loss", linewidth=2)
        ax2.set_title("Baseline CNN - Loss Curve", fontweight="bold", color="#1B4332")
        ax2.set_xlabel("Epoch")
        ax2.set_ylabel("Categorical Crossentropy")
        ax2.legend(loc="upper right")

        plt.tight_layout()
        cnn_curve_path = os.path.join(config.ARTIFACTS_DIR, "training_curves_cnn.png")
        plt.savefig(cnn_curve_path, dpi=200)
        plt.close()
        print(f"[Evaluation] Saved {cnn_curve_path}")

    # 3. Training Curves - MobileNetV2
    mob_hist_path = os.path.join(config.ARTIFACTS_DIR, "mobilenet_history.json")
    if os.path.exists(mob_hist_path):
        with open(mob_hist_path, "r") as f:
            mhist = json.load(f)
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4.5))
        ax1.plot(mhist["epochs"], mhist["accuracy"], "o-", color="#1B4332", label="Train Accuracy", linewidth=2.2)
        ax1.plot(mhist["epochs"], mhist["val_accuracy"], "s--", color="#2A9D8F", label="Validation Accuracy", linewidth=2.2)
        ax1.set_title("MobileNetV2 - Transfer Learning Accuracy", fontweight="bold", color="#1B4332")
        ax1.set_xlabel("Epoch")
        ax1.set_ylabel("Accuracy")
        ax1.legend(loc="lower right")
        ax1.set_ylim([0, 1.05])

        ax2.plot(mhist["epochs"], mhist["loss"], "o-", color="#1B4332", label="Train Loss", linewidth=2.2)
        ax2.plot(mhist["epochs"], mhist["val_loss"], "s--", color="#2A9D8F", label="Validation Loss", linewidth=2.2)
        ax2.set_title("MobileNetV2 - Loss Curve", fontweight="bold", color="#1B4332")
        ax2.set_xlabel("Epoch")
        ax2.set_ylabel("Categorical Crossentropy")
        ax2.legend(loc="upper right")

        plt.tight_layout()
        mob_curve_path = os.path.join(config.ARTIFACTS_DIR, "training_curves_mobilenet.png")
        plt.savefig(mob_curve_path, dpi=200)
        plt.close()
        print(f"[Evaluation] Saved {mob_curve_path}")

    # 4. Model Comparison Bar Chart
    if has_cnn and has_mobilenet:
        plt.figure(figsize=(8, 4.8))
        metrics = ["Test Accuracy", "Macro F1", "Weighted F1"]
        cnn_vals = [
            results["models"]["Baseline_CNN"]["accuracy"],
            results["models"]["Baseline_CNN"]["macro_f1"],
            results["models"]["Baseline_CNN"]["weighted_f1"]
        ]
        mob_vals = [
            results["models"]["MobileNetV2"]["accuracy"],
            results["models"]["MobileNetV2"]["macro_f1"],
            results["models"]["MobileNetV2"]["weighted_f1"]
        ]
        x = np.arange(len(metrics))
        width = 0.35

        plt.bar(x - width/2, cnn_vals, width, label="Baseline CNN", color="#74C69D", edgecolor="#1B4332")
        plt.bar(x + width/2, mob_vals, width, label="MobileNetV2 (Transfer)", color="#1B4332", edgecolor="#081C15")
        plt.ylabel("Score (0.0 to 1.0)", fontweight="bold")
        plt.title("Empirical Model Performance Comparison", fontsize=12, fontweight="bold", color="#1B4332", pad=12)
        plt.xticks(x, metrics, fontweight="bold")
        plt.ylim([0, 1.15])
        plt.legend()
        for i in range(len(metrics)):
            plt.text(x[i] - width/2, cnn_vals[i] + 0.02, f"{cnn_vals[i]:.2f}", ha="center", fontsize=9, fontweight="bold")
            plt.text(x[i] + width/2, mob_vals[i] + 0.02, f"{mob_vals[i]:.2f}", ha="center", fontsize=9, fontweight="bold")
        plt.tight_layout()
        comp_path = os.path.join(config.ARTIFACTS_DIR, "model_comparison.png")
        plt.savefig(comp_path, dpi=200)
        plt.close()
        print(f"[Evaluation] Saved {comp_path}")

    # 5. Class Distribution Chart
    plt.figure(figsize=(10, 4.5))
    splits = ["train", "val", "test"]
    split_colors = ["#2D6A4F", "#52B788", "#95D5B2"]
    split_data = {s: [] for s in splits}
    for s in splits:
        for c in class_labels:
            cdir = os.path.join(config.SAMPLE_DATASET_DIR, s, c)
            cnt = len([f for f in os.listdir(cdir) if f.lower().endswith(('.jpg', '.jpeg', '.png'))]) if os.path.exists(cdir) else 0
            split_data[s].append(cnt)

    x = np.arange(len(class_labels))
    width = 0.25
    for i, s in enumerate(splits):
        plt.bar(x + (i - 1) * width, split_data[s], width, label=s.capitalize(), color=split_colors[i])

    plt.xlabel("Plant Disease Categories", fontweight="bold")
    plt.ylabel("Number of Leaf Images", fontweight="bold")
    plt.title("Stratified Dataset Split Distribution (Zero Data Leakage)", fontsize=12, fontweight="bold", color="#1B4332")
    plt.xticks(x, [c.replace("___", "\n") for c in class_labels], fontsize=9)
    plt.legend()
    plt.tight_layout()
    dist_path = os.path.join(config.ARTIFACTS_DIR, "class_distribution.png")
    plt.savefig(dist_path, dpi=200)
    plt.close()
    print(f"[Evaluation] Saved {dist_path}")

    # Save evaluation_metrics.json
    with open(config.EVALUATION_METRICS_PATH, "w") as f:
        json.dump(results, f, indent=2)
    print(f"[Evaluation] Saved evaluation metrics to {config.EVALUATION_METRICS_PATH}")

    return results


if __name__ == "__main__":
    run_evaluation()
