"""
LEAFGUARD AI - Preprocessing and Data Pipeline
Handles image normalization, training-time data augmentation (preventing data leakage),
and web inference preprocessing.
"""
import os
import io
import sys
from typing import Tuple, Optional
from PIL import Image
import numpy as np

# Ensure root directory is importable
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import config


def preprocess_image_for_model(
    image_input,
    target_size: Tuple[int, int] = (config.IMG_HEIGHT, config.IMG_WIDTH),
    model_type: str = "mobilenet"
) -> Tuple[Optional[np.ndarray], Optional[str]]:
    """
    Validates, loads, resizes, and normalizes a single image for model inference.
    Supports file path (str), file-like object, or bytes.
    Returns: (preprocessed_tensor, error_string)
    """
    try:
        if isinstance(image_input, str):
            if not os.path.exists(image_input):
                return None, f"Image path does not exist: {image_input}"
            img = Image.open(image_input)
        elif isinstance(image_input, (bytes, bytearray)):
            img = Image.open(io.BytesIO(image_input))
        else:
            # File-like stream (e.g., werkzeug FileStorage.stream)
            img = Image.open(image_input)

        # Verify readability
        img = img.convert("RGB")
        w, h = img.size

        if w < 16 or h < 16:
            return None, "Image is too small (minimum 16x16 required)."

        # Resize with high-quality Lanczos resampling
        img_resized = img.resize(target_size, Image.Resampling.LANCZOS)
        arr = np.array(img_resized, dtype=np.float32)

        # Model-specific normalization
        if model_type.lower() == "mobilenet":
            # MobileNetV2 expects values in [-1, 1]
            arr = (arr / 127.5) - 1.0
        else:
            # Baseline CNN expects values in [0, 1]
            arr = arr / 255.0

        # Expand batch dimension: (1, H, W, C)
        tensor = np.expand_dims(arr, axis=0)
        return tensor, None

    except Exception as e:
        return None, f"Failed to process image: {str(e)}"


def get_data_generators(
    dataset_dir: str = config.SAMPLE_DATASET_DIR,
    target_size: Tuple[int, int] = (config.IMG_HEIGHT, config.IMG_WIDTH),
    batch_size: int = config.BATCH_SIZE,
    model_type: str = "mobilenet"
):
    """
    Builds data generators for train, validation, and test splits.
    CRITICAL: Data augmentation is applied ONLY to the training generator to prevent data leakage.
    Validation and test sets undergo ONLY deterministic resizing and normalization.
    """
    import tensorflow as tf
    from tensorflow.keras.preprocessing.image import ImageDataGenerator

    train_dir = os.path.join(dataset_dir, "train")
    val_dir = os.path.join(dataset_dir, "val")
    test_dir = os.path.join(dataset_dir, "test")

    # Rescaling logic
    if model_type.lower() == "mobilenet":
        # mobilenet_v2.preprocess_input maps [0, 255] -> [-1, 1]
        preprocessing_fn = tf.keras.applications.mobilenet_v2.preprocess_input
        rescale = None
    else:
        preprocessing_fn = None
        rescale = 1.0 / 255.0

    # Training Generator with Data Augmentation
    train_datagen = ImageDataGenerator(
        rescale=rescale,
        preprocessing_function=preprocessing_fn,
        rotation_range=20,
        width_shift_range=0.1,
        height_shift_range=0.1,
        shear_range=0.1,
        zoom_range=0.15,
        horizontal_flip=True,
        vertical_flip=True,
        fill_mode="nearest"
    )

    # Validation & Test Generators (NO Augmentation - Zero Data Leakage)
    eval_datagen = ImageDataGenerator(
        rescale=rescale,
        preprocessing_function=preprocessing_fn
    )

    train_generator = train_datagen.flow_from_directory(
        train_dir,
        target_size=target_size,
        batch_size=batch_size,
        class_mode="categorical",
        classes=config.TARGET_CLASSES,
        shuffle=True,
        seed=config.RANDOM_SEED
    )

    val_generator = eval_datagen.flow_from_directory(
        val_dir,
        target_size=target_size,
        batch_size=batch_size,
        class_mode="categorical",
        classes=config.TARGET_CLASSES,
        shuffle=False
    )

    test_generator = eval_datagen.flow_from_directory(
        test_dir,
        target_size=target_size,
        batch_size=batch_size,
        class_mode="categorical",
        classes=config.TARGET_CLASSES,
        shuffle=False
    )

    return train_generator, val_generator, test_generator
