"""
LEAFGUARD AI - MobileNetV2 Transfer Learning Model Training
Trains a deep convolutional transfer-learning classifier using MobileNetV2
pretrained on ImageNet, with a specialized classification head, early stopping,
and validation checkpointing.
"""
import os
import sys
import json
import time
import tensorflow as tf
from tensorflow.keras import layers, models, optimizers, callbacks

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import config
from ml.preprocess import get_data_generators


def build_transfer_learning_model(
    input_shape=(config.IMG_HEIGHT, config.IMG_WIDTH, 3),
    num_classes=len(config.TARGET_CLASSES)
):
    """
    Constructs a transfer-learning model leveraging MobileNetV2 as a feature extractor.
    The backbone weights from ImageNet are frozen to retain general visual representations
    while training the botanical disease classification head.
    """
    base_model = tf.keras.applications.MobileNetV2(
        input_shape=input_shape,
        include_top=False,
        weights="imagenet"
    )
    # Freeze the pretrained backbone
    base_model.trainable = False

    inputs = layers.Input(shape=input_shape, name="input_leaf")
    # Base feature extraction
    x = base_model(inputs, training=False)
    # Spatial aggregation
    x = layers.GlobalAveragePooling2D(name="global_avg_pool")(x)
    # Dense classification head
    x = layers.Dense(128, activation="relu", name="dense_head")(x)
    x = layers.BatchNormalization(name="batch_norm")(x)
    x = layers.Dropout(0.3, name="head_dropout")(x)
    outputs = layers.Dense(num_classes, activation="softmax", name="prediction_probabilities")(x)

    model = models.Model(inputs=inputs, outputs=outputs, name="MobileNetV2_LeafGuard")

    model.compile(
        optimizer=optimizers.Adam(learning_rate=config.LEARNING_RATE),
        loss="categorical_crossentropy",
        metrics=["accuracy"]
    )
    return model


def train_transfer_learning():
    os.makedirs(config.MODELS_DIR, exist_ok=True)
    os.makedirs(config.ARTIFACTS_DIR, exist_ok=True)

    print("[MobileNetV2 Transfer Learning] Preparing data generators...")
    train_gen, val_gen, test_gen = get_data_generators(model_type="mobilenet")

    # Ensure class mapping exists
    class_indices = train_gen.class_indices
    index_to_class = {v: k for k, v in class_indices.items()}
    with open(config.CLASS_NAMES_FILE, "w") as f:
        json.dump(index_to_class, f, indent=2)

    model = build_transfer_learning_model(num_classes=len(class_indices))
    model.summary()

    # Callbacks: EarlyStopping and ModelCheckpoint
    checkpoint_cb = callbacks.ModelCheckpoint(
        filepath=config.MOBILENET_MODEL_PATH,
        monitor="val_accuracy",
        mode="max",
        save_best_only=True,
        verbose=1
    )
    early_stopping_cb = callbacks.EarlyStopping(
        monitor="val_loss",
        patience=4,
        restore_best_weights=True,
        verbose=1
    )

    print(f"[MobileNetV2 Transfer Learning] Training for up to {config.MOBILENET_EPOCHS} epochs...")
    start_time = time.time()
    history = model.fit(
        train_gen,
        validation_data=val_gen,
        epochs=config.MOBILENET_EPOCHS,
        callbacks=[checkpoint_cb, early_stopping_cb],
        verbose=1
    )
    training_time = round(time.time() - start_time, 2)
    print(f"[MobileNetV2 Transfer Learning] Training finished in {training_time}s.")

    # Save final model explicitly
    model.save(config.MOBILENET_MODEL_PATH)
    print(f"[MobileNetV2 Transfer Learning] Saved model weights to {config.MOBILENET_MODEL_PATH}")

    # Save training history
    epochs_trained = len(history.history["loss"])
    history_dict = {
        "epochs": list(range(1, epochs_trained + 1)),
        "accuracy": [float(x) for x in history.history["accuracy"]],
        "val_accuracy": [float(x) for x in history.history["val_accuracy"]],
        "loss": [float(x) for x in history.history["loss"]],
        "val_loss": [float(x) for x in history.history["val_loss"]],
        "training_time_seconds": training_time
    }
    history_file = os.path.join(config.ARTIFACTS_DIR, "mobilenet_history.json")
    with open(history_file, "w") as f:
        json.dump(history_dict, f, indent=2)

    return model, history_dict


if __name__ == "__main__":
    train_transfer_learning()
