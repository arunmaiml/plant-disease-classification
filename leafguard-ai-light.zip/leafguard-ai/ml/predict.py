"""
LEAFGUARD AI - Inference Prediction Service
Loads the trained model and class index mapping, runs inference on leaf images,
ranks class probabilities, flags uncertain predictions, and attaches botanical metadata.
"""
import os
import sys
import json
import numpy as np
import tensorflow as tf

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import config
from ml.preprocess import preprocess_image_for_model


class LeafPredictor:
    _instance = None

    def __init__(self):
        self.model = None
        self.model_type = "mobilenet"
        self.idx_to_class = {}
        self.is_loaded = False
        self.model_name = "None"
        self.load_model()

    @classmethod
    def get_instance(cls):
        if cls._instance is None:
            cls._instance = LeafPredictor()
        return cls._instance

    def load_model(self):
        """Loads trained MobileNetV2 model or falls back to Baseline CNN."""
        # 1. Load class mapping
        if os.path.exists(config.CLASS_NAMES_FILE):
            with open(config.CLASS_NAMES_FILE, "r") as f:
                raw_mapping = json.load(f)
            self.idx_to_class = {int(k): v for k, v in raw_mapping.items()}
        else:
            self.idx_to_class = {i: c for i, c in enumerate(config.TARGET_CLASSES)}

        # 2. Prefer MobileNetV2
        if os.path.exists(config.MOBILENET_MODEL_PATH):
            try:
                self.model = tf.keras.models.load_model(config.MOBILENET_MODEL_PATH)
                self.model_type = "mobilenet"
                self.model_name = "MobileNetV2 (Transfer Learning)"
                self.is_loaded = True
                print(f"[Predictor] Loaded MobileNetV2 model from {config.MOBILENET_MODEL_PATH}")
                return
            except Exception as e:
                print(f"[Predictor] Failed to load MobileNetV2: {e}")

        # 3. Fallback to Baseline CNN
        if os.path.exists(config.BASELINE_MODEL_PATH):
            try:
                self.model = tf.keras.models.load_model(config.BASELINE_MODEL_PATH)
                self.model_type = "cnn"
                self.model_name = "Baseline CNN"
                self.is_loaded = True
                print(f"[Predictor] Loaded Baseline CNN model from {config.BASELINE_MODEL_PATH}")
                return
            except Exception as e:
                print(f"[Predictor] Failed to load Baseline CNN: {e}")

        self.is_loaded = False
        self.model = None
        self.model_name = "None (No trained weights found)"
        print("[Predictor] Notice: No trained model weights found yet.")

    def predict(self, image_input):
        """
        Executes real model inference on leaf image.
        Returns a structured dictionary or raises an exception.
        """
        if not self.is_loaded or self.model is None:
            # Try reloading once in case it was just trained
            self.load_model()
            if not self.is_loaded:
                return {
                    "success": False,
                    "error": "Trained model is not loaded. Please train the model before running inference."
                }

        # Preprocess
        tensor, error_msg = preprocess_image_for_model(image_input, model_type=self.model_type)
        if error_msg or tensor is None:
            return {
                "success": False,
                "error": error_msg or "Failed to preprocess image."
            }

        # Predict
        raw_probs = self.model.predict(tensor, verbose=0)[0]
        pred_idx = int(np.argmax(raw_probs))
        top_prob = float(raw_probs[pred_idx])
        pred_class = self.idx_to_class.get(pred_idx, "Unknown")

        # Top-3 ranked classes
        ranked_indices = np.argsort(raw_probs)[::-1]
        top_k = []
        for idx in ranked_indices[:min(3, len(ranked_indices))]:
            c_name = self.idx_to_class.get(int(idx), f"Class {idx}")
            prob = float(raw_probs[idx])
            meta = config.CLASS_METADATA.get(c_name, {})
            top_k.append({
                "class_name": c_name,
                "display_name": c_name.replace("___", " - ").replace("_", " "),
                "crop": meta.get("crop", "Unknown"),
                "condition": meta.get("condition", c_name),
                "status": meta.get("status", "Unknown"),
                "probability": round(prob, 4),
                "percentage": round(prob * 100, 2)
            })

        # Uncertainty evaluation
        is_uncertain = bool(top_prob < config.UNCERTAINTY_THRESHOLD)
        uncertainty_message = None
        if is_uncertain:
            uncertainty_message = (
                f"The model has low diagnostic confidence ({round(top_prob * 100, 1)}% < "
                f"{int(config.UNCERTAINTY_THRESHOLD * 100)}% threshold). "
                "The image may have suboptimal lighting, background interference, a compound leaf lesion, "
                "or represent an unsupported plant species. Please inspect with a clearer photograph "
                "or consult a certified agricultural extension officer."
            )

        metadata = config.CLASS_METADATA.get(pred_class, {
            "crop": "Botanical Specimen",
            "condition": pred_class.replace("___", " - "),
            "pathogen": "Unknown",
            "status": "Unknown",
            "symptoms": "Symptoms not documented for this class.",
            "description": "Category representation from dataset.",
            "management": "Consult certified agricultural specialist."
        })

        return {
            "success": True,
            "model_version": self.model_name,
            "predicted_class": pred_class,
            "predicted_display": pred_class.replace("___", " - ").replace("_", " "),
            "confidence": round(top_prob, 4),
            "confidence_percent": round(top_prob * 100, 2),
            "is_uncertain": is_uncertain,
            "uncertainty_threshold": config.UNCERTAINTY_THRESHOLD,
            "uncertainty_message": uncertainty_message,
            "status": metadata.get("status", "Unknown"),
            "crop": metadata.get("crop", "Unknown"),
            "pathogen": metadata.get("pathogen", "N/A"),
            "symptoms": metadata.get("symptoms", ""),
            "description": metadata.get("description", ""),
            "management": metadata.get("management", ""),
            "top_3_predictions": top_k,
            "disclaimer": (
                "Educational Prototype Notice: LeafGuard AI is an academic demonstration system. "
                "Predictions are strictly statistical estimates on supported classes and must not be "
                "relied upon as professional agricultural or phytopathological diagnosis."
            )
        }

    def get_info(self):
        """Returns metadata for the /api/model-info endpoint."""
        return {
            "model_loaded": self.is_loaded,
            "active_model": self.model_name,
            "model_type": self.model_type,
            "input_dimensions": [config.IMG_HEIGHT, config.IMG_WIDTH, config.IMG_CHANNELS],
            "uncertainty_threshold": config.UNCERTAINTY_THRESHOLD,
            "supported_classes": [
                {
                    "class_name": c,
                    "display_name": c.replace("___", " - ").replace("_", " "),
                    "crop": config.CLASS_METADATA.get(c, {}).get("crop", "Solanaceae"),
                    "status": config.CLASS_METADATA.get(c, {}).get("status", "Unknown"),
                    "condition": config.CLASS_METADATA.get(c, {}).get("condition", c)
                } for c in config.TARGET_CLASSES
            ]
        }
